import { Component, OnInit, Input } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/toPromise';
import { Shape } from '../shape';

@Component({
  selector: 'app-canvas',
  templateUrl: './canvas.component.html',
  styleUrls: ['./canvas.component.css']
})
export class CanvasComponent implements OnInit {
  constructor() { }
  @Input() shapesToDraw: Shape[];
  shapeType = 'rectangle';
  isPreventClickEvent=true;
  currentSelection = '';
  isShowPop = false;
  popupPromiseStatusObjects: any;

  setType(type: string) { this.shapeType = type; }

  @Input() currentShape: Subject<Shape>;

  ngOnInit() { 
   // this.showPop();
  }

  // the shape being just drawn
  createdShape: Shape;


  async showPop() {
    let popupAfterClose;
    try {
      popupAfterClose = await this.openPopup();
      console.log(popupAfterClose); // ok message from promise resolve
    } catch (error) {
      console.log(error); // cancel message from promise rejected
    }
    console.log('continue ***'); // continue your next line of codes
    console.log('continue **********');
  }
  openPopup() {
    this.isShowPop = true;
    return new Promise((resolve, reject) => {
      this.popupPromiseStatusObjects = {
        resolve,
        reject
      };
    });
  }
  okCancelPopup(btn) {
    if (btn == 'ok') {
      this.createdShape.name = this.currentSelection;
      this.currentSelection = '';
      this.isPreventClickEvent = true;
      this.popupPromiseStatusObjects.resolve('ok');
    } else {
      this.isPreventClickEvent = true;
      this.popupPromiseStatusObjects.reject('cancel');
    }
    this.isShowPop = false;
  }

  startDrawing(evt: MouseEvent) {
    this.createdShape = {
      type: this.shapeType,
      x: evt.offsetX,
      y: evt.offsetY,
      w: 0,
      h: 0,
      name: ''
    };
    this.shapesToDraw.push(this.createdShape);
  }

  keepDrawing(evt: MouseEvent) {
    if (this.createdShape) {
      this.currentShape.next(this.createdShape);
      this.createdShape.w = evt.offsetX - this.createdShape.x;
      this.createdShape.h = evt.offsetY - this.createdShape.y;
    }
  }

  clickDrawing(evt: MouseEvent) {
    if(this.isPreventClickEvent) return;
    let area = this.shapesToDraw.filter((data)=>{
      return (evt.offsetX > data.x && evt.offsetX < data.x+data.w && evt.offsetY > data.y && evt.offsetY < data.y+data.h );
    });
    if(area.length){
      if(area.length === 1){
        alert(area[0].name);
      }else {
        let sNo = area[0].x;
        let sInd = 0;
        for (let i=0; i<area.length; i++) {
          if(sNo > area[i].x){
            sNo = sNo;
            sInd = sInd;
          }else{
            sNo = area[i].x;
            sInd = i;
          }
        }
        alert(area[sInd].name);
      }
    }
  }
  onSelectFile(evt) {
    var tgt = evt.target || window.event.srcElement,
        files = tgt.files;
    // FileReader support
    if (FileReader && files && files.length) {
        var fr = new FileReader();
        fr.onload = function () {
            document.getElementById('outImage')['src'] = fr.result;
        }
        fr.readAsDataURL(files[0]);
    }

    // Not supported
    else {
        // fallback -- perhaps submit the input to an iframe and temporarily store
        // them on the server until the user's session ends.
    }
}
showMenu(){
  alert('mody');
  return false;
}

  stopDrawing(evt: MouseEvent) {
    if(this.createdShape.h == 0 && this.createdShape.w == 0){
      this.isPreventClickEvent = false;
      this.shapesToDraw.pop();
    }else{
      var wa = prompt('Please enter work area name', '');
      if (wa != null) {
        this.createdShape.name = wa;
      }
      this.isPreventClickEvent = true;
     // let a = this.showPop();
     this.createdShape = null;
    }
  }

}