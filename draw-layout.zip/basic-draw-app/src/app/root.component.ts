import { Component, OnInit } from '@angular/core';

@Component({
  template: '<router-outlet></router-outlet>',
  selector:'app-root1'
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}