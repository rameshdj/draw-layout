export class Shape {
  type: string;
  x:number;
  y:number;
  w:number;
  h:number;
  name:string;
}
